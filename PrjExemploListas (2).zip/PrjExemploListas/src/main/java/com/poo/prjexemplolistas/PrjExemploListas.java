/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjexemplolistas;

import com.poo.prjexemplolistas.objetos.Aluno;
import com.poo.prjexemplolistas.objetos.Disciplina;
import com.poo.prjexemplolistas.objetos.Professor;
import com.poo.prjexemplolistas.util.MostrarDados;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author IFTM
 */
public class PrjExemploListas {

    public static void main(String[] args) {
        
        Disciplina disciplina = new Disciplina();
        Aluno aluno = new Aluno();
        Aluno aluno2 = new Aluno();
        Professor professor = new Professor ();
        
        professor.setNome("Um Professor ai");
        professor.setGraduacao("ADS");
        professor.setCpf("123.968.794-00");
        
        aluno.setNome("Aluno 1");
        aluno.setCpf("123.000.000-00");
        aluno.setDataNasc("01/03/2012");
                
        aluno2.setNome("Aluno 2");
        aluno2.setCpf("123.000.000-99");
        aluno2.setDataNasc("01/03/2014");
        
        List<Aluno> lstAlunos = new ArrayList<Aluno>();
        lstAlunos.add(aluno);
        lstAlunos.add(aluno2);
                
        disciplina.setNome("Geografia");
        disciplina.setPeriodo(2);
        disciplina.setCargaHoraria(80);
        disciplina.setProfessor(professor);
        disciplina.setLstAlunos(lstAlunos);
        
        List<Disciplina> lstDisciplina = new ArrayList<>();
        lstDisciplina.add(disciplina);
        aluno.setLstDisciplina(lstDisciplina);
        aluno2.setLstDisciplina(lstDisciplina);
        
        professor.setLstDisciplina(lstDisciplina);
           
        MostrarDados md = new MostrarDados();
        md.mostrar(disciplina);
        md.mostrar(aluno);
        md.mostrar(aluno2);
        md.mostrar(professor);
    }
}
