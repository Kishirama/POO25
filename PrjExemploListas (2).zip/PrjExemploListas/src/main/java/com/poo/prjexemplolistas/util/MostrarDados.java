/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexemplolistas.util;

import com.poo.prjexemplolistas.objetos.Aluno;
import com.poo.prjexemplolistas.objetos.Disciplina;
import com.poo.prjexemplolistas.objetos.Professor;

/**
 *
 * @author IFTM
 */
public class MostrarDados {
    
    public void mostrar(Disciplina d){
        
        System.out.println("Nome: "+d.getNome());
        System.out.println("Periodo: "+d.getPeriodo());
        System.out.println("Carga Horaria: "+d.getCargaHoraria());
        System.out.println("Professsor: "+d.getProfessor().getNome());
        d.getLstAlunos();
        System.out.println("========================================");
        
        for (Aluno a : d.getLstAlunos()){
            System.out.println("Nome: "+ a.getNome());
            System.out.println("Data de Nasc.: "+a.getDataNasc());
            System.out.println("======================================");
        }   
        
    }
    public void mostrar (Aluno a){
        System.out.println("Nome:" +a.getNome());
        System.out.println("CPF: " + a.getCpf());
        System.out.println("Data de Nasc: "+a.getDataNasc());
        
        for(Disciplina d : a.getLstDisciplina()){
            
            System.out.println("Nome: " +d.getNome());
            System.out.println("Carga Horaria: "+d.getCargaHoraria());
        }
            
    }
    public void mostrar (Professor p){
        System.out.println("Nome:" +p.getNome());
        System.out.println("CPF: " + p.getCpf());
        System.out.println("Data de Nasc: "+p.getGraduacao());
        
        for(Disciplina d : p.getLstDisciplina()){
            
            System.out.println("Nome: " +d.getNome());
            System.out.println("Carga Horaria: "+d.getCargaHoraria());
        }
    }        
}
