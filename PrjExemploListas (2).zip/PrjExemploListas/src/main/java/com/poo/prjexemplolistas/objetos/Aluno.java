 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexemplolistas.objetos;

import java.util.List;

/**
 *
 * @author IFTM
 */
public class Aluno {
    private String nome;
    private String dataNasc;
    private String cpf;
    private List<Disciplina> lstDisciplina;    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public List<Disciplina> getLstDisciplina() {
        return lstDisciplina;
    }

    public void setLstDisciplina(List<Disciplina> lstDisciplina) {
        this.lstDisciplina = lstDisciplina;
    }
}
