/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexemploconexao.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author iftm
 */
public class Conexao {
    
    final private String driver="";
    final private String url="";
    final private String usuario = "root";
    final private String senha = "123456";
    
    public Connection conectar(){
        
        Connection conn = null;
        
        try{
            Class.forName(driver);
            conn = DriverManager.getConnection(url,usuario,senha);
           
        }
        
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return conn;
    }
}
