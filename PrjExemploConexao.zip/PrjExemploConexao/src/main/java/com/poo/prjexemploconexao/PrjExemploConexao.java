/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjexemploconexao;

/**
 *
 * @author iftm
 */
public class PrjExemploConexao {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
