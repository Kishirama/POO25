/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjgerencia_veiculos;

import com.poo.prjgerencia_veiculos.classes.*;

/**
 *
 * @author IFTM
 */
public class PrjGerencia_Veiculos {

    public static void main(String[] args) {
        
        Moto m1 = new Moto();
        m1.setMarca("Alguma Marca");
        m1.setAno(2010);
        m1.setCilindrada("655");
        
        String dados = m1.getMarca() + "; " + m1.getAno() + "; " + m1.getCilindrada();
        System.out.println(dados);
        
    }
}
