/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjgerencia_veiculos.classes;

/**
 *
 * @author IFTM
 */
public class Carro extends Veiculo {
    
    public String antena;

    public String getAntena() {
        return antena;
    }

    public void setAntena(String antena) {
        this.antena = antena;
    }
    
}
