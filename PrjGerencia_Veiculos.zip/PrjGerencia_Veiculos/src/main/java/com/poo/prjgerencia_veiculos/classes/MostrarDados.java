/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjgerencia_veiculos.classes;

/**
 *
 * @author IFTM
 */
public class MostrarDados {
    
    public void mostrar (Veiculo v){
        
        System.out.println("Marca:" + v.getMarca());
    }
    
    public void mostrar (Carro c){
        
        System.out.println("Marca:" + c.getMarca());
        System.out.println("Ano: "+ c.getAno());
        System.out.println("Possui Antena: "+ c.getAntena() + ", Sim = É um Kwid // Não = Não é um Kwid");
    }
    public void mostrar (Moto m){
        
        System.out.println("Marca: "+ m.getMarca());
        System.out.println("Ano: " + m.getAno());
        System.out.println("Cilindrada: " + m.getCilindrada());
    }
    
}
