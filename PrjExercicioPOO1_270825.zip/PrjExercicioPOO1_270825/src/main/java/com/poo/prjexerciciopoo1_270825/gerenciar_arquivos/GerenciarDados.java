/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexerciciopoo1_270825.gerenciar_arquivos;

import com.poo.prjexerciciopoo1_270825.objetos.Carro;
import com.poo.prjexerciciopoo1_270825.objetos.Moto;
import com.poo.prjexerciciopoo1_270825.objetos.Veiculo;
import com.poo.prjexerciciopoo1_270825.util.EscreverArquivo;
import com.poo.prjexerciciopoo1_270825.util.LerArquivo;
import java.io.BufferedReader;
import java.io.IOException;

/**
 *
 * @author clc
 */
public class GerenciarDados 
{
    EscreverArquivo e_arq;
    LerArquivo l_arq;

    public GerenciarDados() 
    {
        e_arq = new EscreverArquivo();
        l_arq = new LerArquivo();
    }
    
    public void salvarDados(Carro c)
    {
        String arquivo = "c:\\ArquivoCarro.txt";
        String dados = c.getMarca()+"; "+c.getModelo()+"; "+c.getAno()+"; "+c.getPortas();
        
        e_arq.escrever(arquivo, dados, true);
    }

    public void salvarDados(Moto m)
    {
        String arquivo = "c:\\ArquivoMoto.txt";
        String dados = m.getMarca()+"; "+m.getModelo()+"; "+m.getAno()+"; "+m.getPartidaEletrica();
        
        e_arq.escrever(arquivo, dados, true);
    }
    
    public void buscarDados(String nome)
    {
        if(nome.equals(Moto.class.getSimpleName()))
        {
            String arquivo = "c:\\ArquivoMoto.txt";
            BufferedReader br = l_arq.ler(arquivo);
            
            lerBuffer(br, new Moto());
        }
        else if(nome.equals(Carro.class.getSimpleName()))
        {
            String arquivo = "c:\\ArquivoCarro.txt";
            BufferedReader br = l_arq.ler(arquivo);
            
            lerBuffer(br, new Carro());
        }
    }    //object vai receber de forma generica carro ou moto de forma a executar uma linha de comando
    public void lerBuffer(BufferedReader br, Object veiculo)
    {
        try 
        {
            //enquanto houver algo no buffer ele vai ler
            while(br.ready())
            {
                /*readline vai ler a linha,split vai separar a cada ";" em vetores*/
                String partesLinha[] = br.readLine().split(";");
                //getclass vai usar o object para saber qual classe de veiculo vai usar, e simplesname vai comparar a string*/
                if(veiculo.getClass().getSimpleName().equals("Moto"))
                {
                    Moto m = (Moto) veiculo;
                    m.setMarca(partesLinha[0].trim());
                    m.setModelo(partesLinha[1].trim());
                    m.setAno(Integer.parseInt(partesLinha[2].trim()));
                    m.setPartidaEletrica(Boolean.parseBoolean(partesLinha[3].trim()));
                    mostrarDados(m);
                    System.out.println("");
                }
                else if(veiculo.getClass().getSimpleName().equals("Carro"))
                {
                    Carro c = (Carro) veiculo;
                    c.setMarca(partesLinha[0].trim());
                    c.setModelo(partesLinha[1].trim());
                    c.setAno(Integer.parseInt(partesLinha[2].trim()));
                    c.setPortas(Integer.parseInt(partesLinha[3].trim()));
                    mostrarDados(c);
                    System.out.println("");
                }                
            }
        } 
        catch (IOException ex) 
        {
            ex.printStackTrace();
        }
    }
    
    private void mostrarDados(Veiculo v)
    {
        System.out.println("Marca: "+ v.getMarca());
        System.out.println("Modelo: "+ v.getModelo());
        System.err.println("Ano: "+ v.getAno());
    }
    private void mostrarDados(Moto m)
    {
        mostrarDados((Veiculo)m);
        //==true? em caso de V recebe o sim caso F recebe o não
        System.out.println("Partida Eletrica: "+ ((m.getPartidaEletrica() == true)?"Sim":"Não"));
    }
    private void mostrarDados(Carro c)
    {
        mostrarDados((Veiculo)c);
        System.out.println("Portas: "+ c.getPortas());
    }
}


