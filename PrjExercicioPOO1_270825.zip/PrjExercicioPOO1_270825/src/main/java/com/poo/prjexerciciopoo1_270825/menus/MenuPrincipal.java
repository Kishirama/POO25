/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexerciciopoo1_270825.menus;

import java.util.Scanner;

/**
 *
 * @author clc
 */
public class MenuPrincipal 
{
    public static void mostrarMenuPrincipal()
    {
        //Entrada de arquivo via terminal usando a util Scanner
        Scanner scanner = new Scanner(System.in);
        //forma de entrada no while
        int opcao = -1;

        while (opcao != 0){
            System.out.println("====== MENU PRINCIPAL ======");
            System.out.println("1 - Gerenciar Dados Moto");
            System.out.println("2 - Gerenciar Dados Carro");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            //Nextint e para proxima entrada do teclado
            opcao = scanner.nextInt();

            switch (opcao) {
                //Seguindo a entrada, sera redirecionado a outros menus, default para qualquer entrada diferente
                case 1 -> MenuDadosMoto.opcoesMoto(scanner);
                case 2 -> MenuDadosCarro.opcoesCarro(scanner);
                case 0 -> System.out.println("Encerrando o sistema...");
                default -> System.out.println("Opcao invalida.");
            }
        }
        scanner.close();
    }
    
}
