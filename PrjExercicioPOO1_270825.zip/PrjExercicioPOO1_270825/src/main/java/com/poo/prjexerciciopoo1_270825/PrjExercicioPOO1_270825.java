/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjexerciciopoo1_270825;

import com.poo.prjexerciciopoo1_270825.menus.MenuPrincipal;
import com.poo.prjexerciciopoo1_270825.objetos.*;
import java.util.Scanner;

/**
 *
 * @author clc
 */
public class PrjExercicioPOO1_270825 {

    public static void main(String[] args) {
        MenuPrincipal.mostrarMenuPrincipal();
    }
}
