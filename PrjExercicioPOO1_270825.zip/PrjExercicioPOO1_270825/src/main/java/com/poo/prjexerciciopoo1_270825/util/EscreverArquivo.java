/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexerciciopoo1_270825.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author clc
 */
public class EscreverArquivo 
{
    public void escrever(String arquivo, String texto, boolean manter)
    {        
        try 
        {
            /*Define o caminho do arquivo que será 
            utilizado para leitura ou escrita*/
            File f = new File(arquivo);
            /*Cria uma instância do arquivo para escrita, manter de não sobreescrever recebendo o true ou false*/
            FileWriter fw = new FileWriter(f, manter);
            /*Cria o meio para escrever no arquivo
            instanciado na linha anterior*/
            PrintWriter pw = new PrintWriter(fw);
            //Escreve no arquivo
            pw.println(texto);
            //Conclui a escrita do arquivo
            fw.close();
        } 
        catch (IOException ex) {
            ex.printStackTrace();
        }       
    }
    
}
