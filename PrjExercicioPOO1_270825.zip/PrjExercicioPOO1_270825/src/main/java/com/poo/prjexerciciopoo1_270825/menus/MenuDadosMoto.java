/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexerciciopoo1_270825.menus;

import com.poo.prjexerciciopoo1_270825.gerenciar_arquivos.GerenciarDados;
import com.poo.prjexerciciopoo1_270825.objetos.Moto;
import java.util.Scanner;

/**
 *
 * @author clc
 */
public class MenuDadosMoto 
{
    public static void opcoesMoto(Scanner scanner)
    {
        GerenciarDados gd = new GerenciarDados();
        int opcao;

        do 
        {
            System.out.println("=== MENU DE OPCOES ===");
            System.out.println("1 - SALVAR");
            System.out.println("2 - CONSULTAR");
            System.out.println("0 - Voltar");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 ->{
                    Moto m = new Moto();
                    System.out.print("Marca: ");
                    m.setMarca(scanner.next());
                    System.out.print("Modelo: ");
                    m.setModelo(scanner.next());
                    System.out.print("Ano: ");
                    m.setAno(scanner.nextInt());
                    System.out.print("Partida Eletrica: ");
                    m.setPartidaEletrica(scanner.next().equals("Sim"));
                    gd.salvarDados(m);
                }
                case 2 -> gd.buscarDados("Moto");             
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opcao invalida.");
            }

        } while (opcao != 0);
    }
    
}
