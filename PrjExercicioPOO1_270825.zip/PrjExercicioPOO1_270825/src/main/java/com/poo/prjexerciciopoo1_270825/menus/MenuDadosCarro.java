/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexerciciopoo1_270825.menus;

import com.poo.prjexerciciopoo1_270825.gerenciar_arquivos.GerenciarDados;
import com.poo.prjexerciciopoo1_270825.objetos.Carro;
import java.util.Scanner;

/**
 *
 * @author clc
 */
public class MenuDadosCarro 
{
    public static void opcoesCarro(Scanner scanner)
    {
        GerenciarDados gd = new GerenciarDados();
        int opcao;

        do 
        {
            System.out.println("=== MENU DE OPCOES ===");
            System.out.println("1 - SALVAR");
            System.out.println("2 - CONSULTAR");
            System.out.println("0 - Voltar");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1 ->{
                    Carro c = new Carro();
                    System.out.print("Marca: ");
                    //Scanner.next vai adicionando uma entrada do teclado para cada opção em sequencia
                    c.setMarca(scanner.next());
                    System.out.print("Modelo: ");
                    c.setModelo(scanner.next());
                    System.out.print("Ano: ");
                    c.setAno(scanner.nextInt());
                    System.out.print("Portas: ");
                    c.setPortas(scanner.nextInt());
                    //Os dados criados para o new carro C, vai usar o gd.salvardados para armazenar aqueles arquivos
                    gd.salvarDados(c);
                }
                case 2 -> gd.buscarDados("Carro");             
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("Opcao invalida.");
            }

        } while (opcao != 0);
    }
    
}
