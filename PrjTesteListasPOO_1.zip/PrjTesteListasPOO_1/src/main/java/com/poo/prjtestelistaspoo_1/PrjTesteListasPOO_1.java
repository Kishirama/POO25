/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjtestelistaspoo_1;

/**
 *
 * @author IFTM
 */
public class PrjTesteListasPOO_1 {

    public static void main(String[] args) {
        ComparacoesListas compl = new ComparacoesListas();
        compl.compArrayList_LinkedList();
        System.out.println("");
        System.out.println("============");
        compl.comparacaoGeralList();
    }
}
