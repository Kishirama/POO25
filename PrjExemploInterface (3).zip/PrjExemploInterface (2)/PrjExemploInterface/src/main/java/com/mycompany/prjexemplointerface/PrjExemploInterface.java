/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjexemplointerface;

import com.mycompany.prjexemplointerface.models.Cliente;
import com.mycompany.prjexemplointerface.models.Gerente;

/**
 *
 * @author iftm
 */
public class PrjExemploInterface {

    public static void main(String[] args) {
        Autenticar aut = new Autenticar ();
        
        Gerente gerente = new Gerente("gerente","senhaForte123");
        Cliente cliente = new Cliente ("cliente", "cli@123");
        
        aut.login(gerente, "senhaForte123");
        aut.login(cliente, "senhaErrada");
        aut.login(cliente, "cli@123");
    }
}
