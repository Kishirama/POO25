/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjexemplointerface;

import com.mycompany.prjexemplointerface.models.Autenticavel;

/**
 *
 * @author iftm
 */
public class Autenticar 
{
    public void login(Autenticavel obj, String senha){
            boolean conseguiuLogar = obj.autenticar(senha);
            
            if (conseguiuLogar){
                System.out.println("Login efetuado no sistema");
            } else {
                System.out.println("Acesso negado.");
            }
        System.out.println("============================");
        
    }
}
