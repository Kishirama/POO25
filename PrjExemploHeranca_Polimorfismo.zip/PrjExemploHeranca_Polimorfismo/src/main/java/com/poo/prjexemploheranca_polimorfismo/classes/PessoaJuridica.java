/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexemploheranca_polimorfismo.classes;

/**
 *
 * @author iftm
 */
public class PessoaJuridica extends Pessoa{
    
    private String cnpj;
    private String insc_Estadual;

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInsc_Estadual() {
        return insc_Estadual;
    }

    public void setInsc_Estadual(String insc_Estadual) {
        this.insc_Estadual = insc_Estadual;
    }
    
    
}
