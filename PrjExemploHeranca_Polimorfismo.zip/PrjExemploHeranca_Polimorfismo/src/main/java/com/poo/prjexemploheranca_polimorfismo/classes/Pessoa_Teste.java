/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexemploheranca_polimorfismo.classes;

/**
 *
 * @author iftm
 */
public class Pessoa_Teste {
    
    private String nome;
    private String cpf;
    private String rg;
    private String cnpj;
    private String insc_Estadual;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getInsc_Estadual() {
        return insc_Estadual;
    }

    public void setInsc_Estadual(String insc_Estadual) {
        this.insc_Estadual = insc_Estadual;
    }
    
}
