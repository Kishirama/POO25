/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poo.prjexemploheranca_polimorfismo;

import com.poo.prjexemploheranca_polimorfismo.classes.EscreverArquivo;
import com.poo.prjexemploheranca_polimorfismo.classes.LerArquivo;
import com.poo.prjexemploheranca_polimorfismo.classes.MostrarDados;
import com.poo.prjexemploheranca_polimorfismo.classes.Pessoa;
import com.poo.prjexemploheranca_polimorfismo.classes.PessoaFisica;
import com.poo.prjexemploheranca_polimorfismo.classes.PessoaJuridica;
import java.util.List;
//import com.poo.prjexemploheranca_polimorfismo.classes.Pessoa_Teste;

/**
 *
 * @author iftm
 */
public class PrjExemploHeranca_Polimorfismo {

    public static void main(String[] args) {
        //Pessoa_Teste pt = new Pessoa_Teste ();
        //pt.setNome("TESTE 1");
        //pt.setCpf("111.222.333-44");
        //pt.setRg("12345678");
        
        //System.out.println(pt.getNome());
        //System.out.println(pt.getCpf());
        //System.out.println(pt.getRg());
        //System.out.println(pt.getCnpj());
        //System.out.println(pt.getInsc_Estadual());
        
        /*Pessoa p = new Pessoa ();
        p.setNome("Teste 1");
        
        PessoaFisica pf = new PessoaFisica();
        pf.setNome("Teste 2");
        pf.setCpf("111.222.333-44");
        pf.setRg("1234567");
        
        PessoaJuridica pj = new PessoaJuridica();
        pj.setNome("Teste 3");
        pj.setCnpj("6.469446464646464684684");
        pj.setInsc_Estadual("656546486784864787");
        
        MostrarDados md = new MostrarDados();
        md.mostrar(p);
        md.mostrar(pf);
        md.mostrar(pj);*/
        
        PessoaFisica pf = new PessoaFisica();
        pf.setNome("Teste 2");
        pf.setCpf("111.222.333-44");
        pf.setRg("1234567");
        
        String dados = pf.getNome() + "; " + pf.getCpf() + "; "+pf.getRg();
        System.out.println(dados);
        
        EscreverArquivo arquivo = new EscreverArquivo ();
        arquivo.escrever(dados);
        
        LerArquivo arq = new LerArquivo ();
        List<String> lstDados = arq.ler();
        
        PessoaFisica pf2 = new PessoaFisica();
        
        for (String linha : lstDados){
            System.out.println(linha);
            String partes [] = linha.split(";"); //separa os arquivos
            pf2.setNome(partes[0]);
            pf2.setCpf(partes[1]);
            pf2.setRg(partes[2]);
        }
        
        MostrarDados md = new MostrarDados();
        md.mostrar(pf2);
    }
}
