/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjexemploheranca_polimorfismo.classes;

/**
 *
 * @author iftm
 */
public class MostrarDados {
    
    public void mostrar (Pessoa p){
        
        System.out.println("Nome:" + p.getNome());
    }
    
    public void mostrar (PessoaFisica pf){
        
        System.out.println("Nome: "+ pf.getNome());
        System.out.println("CPF: "+ pf.getCpf());
        System.out.println("RG: "+ pf.getRg());
    }
    public void mostrar (PessoaJuridica pj){
        
        System.out.println("Nome: "+ pj.getNome());
        System.out.println("CNPJ: "+ pj.getCnpj());
        System.out.println("Ins Estadual: "+ pj.getInsc_Estadual());
    }
    
}
